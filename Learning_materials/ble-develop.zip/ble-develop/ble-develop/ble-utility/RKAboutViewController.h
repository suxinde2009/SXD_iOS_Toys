//
//  RKAboutViewController.h
//  ble-utility
//
//  Created by Du Jun on 11/18/13.
//  Copyright (c) 2013 北京锐和信科技有限公司. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface RKAboutViewController : UIViewController


- (IBAction)contactusAction:(id)sender;
- (IBAction)mailusAction:(id)sender;

@end
