//
//  BLAppDelegate.h
//  ble-utility
//
//  Created by 北京锐和信科技有限公司 on 13-10-29.
//  Copyright (c) 2013年 北京锐和信科技有限公司. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface BLAppDelegate : UIResponder <UIApplicationDelegate>
@property (nonatomic,strong) NSMutableDictionary * uuidNames;
@property (strong, nonatomic) UIWindow *window;
@end
