//
//  CBMutableDescriptor+BluetoothKit.m
//  ble-utility
//
//  Created by joost on 13-11-13.
//  Copyright (c) 2013年 北京锐和信科技有限公司. All rights reserved.
//

#import "CBMutableDescriptor+BluetoothKit.h"

@implementation CBMutableDescriptor(BluetoothKit)
+ (CBMutableDescriptor *)descriptorWithXmlElement:(GDataXMLElement *) element
{
    return nil;
}
@end
