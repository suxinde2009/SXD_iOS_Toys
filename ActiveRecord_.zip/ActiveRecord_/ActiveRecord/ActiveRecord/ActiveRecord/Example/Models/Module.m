//
//  Module.m
//  ActiveRecord
//
//  Created by Michal Konturek on 22/02/2014.
//  Copyright (c) 2014 Michal Konturek. All rights reserved.
//

#import "Module.h"
#import "Student.h"
#import "StudyGroup.h"


@implementation Module

@dynamic name;
@dynamic uid;
@dynamic students;
@dynamic studyGroups;

@end
