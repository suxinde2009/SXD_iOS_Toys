//
//  Registration.m
//  ActiveRecord
//
//  Created by Michal Konturek on 20/03/2014.
//  Copyright (c) 2014 Michal Konturek. All rights reserved.
//

#import "Registration.h"
#import "Student.h"


@implementation Registration

@dynamic uid;
@dynamic date;
@dynamic signature;
@dynamic student;

@end
