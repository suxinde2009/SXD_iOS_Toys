//
//  Course.m
//  ActiveRecord
//
//  Created by Michal Konturek on 22/02/2014.
//  Copyright (c) 2014 Michal Konturek. All rights reserved.
//

#import "Course.h"
#import "Student.h"


@implementation Course

@dynamic uid;
@dynamic name;
@dynamic students;

@end
