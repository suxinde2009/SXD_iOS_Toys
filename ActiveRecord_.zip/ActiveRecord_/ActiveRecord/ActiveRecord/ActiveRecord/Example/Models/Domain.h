//
//  Domain.h
//  ActiveRecord
//
//  Created by Michal Konturek on 22/02/2014.
//  Copyright (c) 2014 Michal Konturek. All rights reserved.
//

#import "Student.h"
#import "StudyGroup.h"
#import "Module.h"
#import "Course.h"
#import "Registration.h"


