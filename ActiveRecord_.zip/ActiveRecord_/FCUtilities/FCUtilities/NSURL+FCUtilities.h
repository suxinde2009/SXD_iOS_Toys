//
//  NSURL+FCUtilities.h
//  Pods
//
//  Created by Marco Arment on 5/9/14.
//
//

#import <Foundation/Foundation.h>

@interface NSURL (FCUtilities)

- (NSDictionary *)fc_queryComponents;

@end
