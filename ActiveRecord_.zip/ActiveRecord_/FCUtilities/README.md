FCUtilities
===========

Common iOS utilities that I've needed for my apps. Hopefully some are useful for yours.
