OS X and iOS File System Events Monitor
=========
copied from www.newosxbook.com code of "Mac OS X and iOS Internals: To The Apple's Core"

Comile
--------------
just exe make in target dir

Caution
--------------
should run with root permission
